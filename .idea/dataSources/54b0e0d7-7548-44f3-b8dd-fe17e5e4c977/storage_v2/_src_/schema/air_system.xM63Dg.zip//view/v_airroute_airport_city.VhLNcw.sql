create view v_airroute_airport_city as
select `air_system`.`tb_airroute`.`airroute_id`     AS `airroute_id`,
       `x`.`airport_name`                           AS `airportUpName`,
       `y`.`airport_name`                           AS `airportDownName`,
       `a`.`city_name`                              AS `cityStartName`,
       `b`.`city_name`                              AS `cityEndName`,
       `air_system`.`tb_airroute`.`airroute_length` AS `airroute_length`
from `air_system`.`tb_airport` `x`
         join `air_system`.`tb_airport` `y`
         join `air_system`.`tb_city` `a`
         join `air_system`.`tb_city` `b`
         join `air_system`.`tb_airroute`
where ((`air_system`.`tb_airroute`.`airport_up` = `x`.`airport_id`) and
       (`air_system`.`tb_airroute`.`airport_down` = `y`.`airport_id`) and (`x`.`city_id` = `a`.`city_id`) and
       (`y`.`city_id` = `b`.`city_id`));

-- comment on column v_airroute_airport_city.airroute_id not supported: 航线编号

-- comment on column v_airroute_airport_city.cityStartName not supported: 城市名称

-- comment on column v_airroute_airport_city.cityEndName not supported: 城市名称

-- comment on column v_airroute_airport_city.airroute_length not supported: 航线长度（公里）

